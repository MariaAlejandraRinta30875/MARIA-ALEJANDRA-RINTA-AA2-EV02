package com.chavitosport.controller;

import com.chavitosport.dao.ProductoDAO;
import com.chavitosport.model.Producto;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class ProductoServlet extends HttpServlet {
    ProductoDAO dao = new ProductoDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Producto> productos = dao.listar();
        request.setAttribute("productos", productos);
        RequestDispatcher dispatcher = request.getRequestDispatcher("listar.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Producto p = new Producto();
        p.setNombre(request.getParameter("nombre"));
        p.setTalla(request.getParameter("talla"));
        p.setPrecio(Double.parseDouble(request.getParameter("precio")));
        dao.insertar(p);
        response.sendRedirect("ProductoServlet");
    }
}