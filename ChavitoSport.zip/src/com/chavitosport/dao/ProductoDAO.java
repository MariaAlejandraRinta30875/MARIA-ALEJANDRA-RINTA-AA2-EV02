package com.chavitosport.dao;

import com.chavitosport.model.*;
import java.sql.*;
import java.util.*;

public class ProductoDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public List<Producto> listar() {
        List<Producto> lista = new ArrayList<>();
        try {
            con = cn.getConexion();
            ps = con.prepareStatement("SELECT * FROM productos");
            rs = ps.executeQuery();
            while (rs.next()) {
                Producto p = new Producto();
                p.setId(rs.getInt(1));
                p.setNombre(rs.getString(2));
                p.setTalla(rs.getString(3));
                p.setPrecio(rs.getDouble(4));
                lista.add(p);
            }
        } catch (Exception e) {
            System.out.println("Error al listar: " + e);
        }
        return lista;
    }

    public void insertar(Producto p) {
        try {
            con = cn.getConexion();
            ps = con.prepareStatement("INSERT INTO productos(nombre, talla, precio) VALUES (?, ?, ?)");
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getTalla());
            ps.setDouble(3, p.getPrecio());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error al insertar: " + e);
        }
    }
}