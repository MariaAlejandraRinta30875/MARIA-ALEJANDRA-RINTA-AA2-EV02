package com.chavitosport.model;

import java.sql.*;

public class Conexion {
    Connection con;

    public Connection getConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/chavitosport", "root", "");
        } catch (Exception e) {
            System.out.println("Error en la conexión: " + e);
        }
        return con;
    }
}